#include <iostream>
/*#include <string>
#include <vector>*/
using namespace std;

#include "Control.h"

int main(){ 
  Control control;
  control.launch();

  cout<<endl<<"------Remove Debug staments, print(), add preambles------"<<endl<<endl;
  return 0;
}
